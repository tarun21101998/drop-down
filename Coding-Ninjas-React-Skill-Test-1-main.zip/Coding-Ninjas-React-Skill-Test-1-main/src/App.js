import Dropdown from "./Dropdown";

function App() {
  return (
    <div className="App">
      <Dropdown />
    </div>
  );
}

export default App;
